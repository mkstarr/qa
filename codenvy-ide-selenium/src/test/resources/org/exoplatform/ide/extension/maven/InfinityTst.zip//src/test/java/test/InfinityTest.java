package test;
import junit.framework.TestCase;

public class InfinityTest extends TestCase {
    boolean infVar = true;

    public void testInfLoop() {
        while (infVar) {
            if (infVar == false)
                break;
        }
    }
}
