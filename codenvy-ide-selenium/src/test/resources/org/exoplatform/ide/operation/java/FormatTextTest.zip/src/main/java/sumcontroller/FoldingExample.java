/* TEST COPY RIGHT
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package helloworld;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FoldingExample implements Controller
{
   @Override
   public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception
   {
      String userName = request.getParameter("user");
      String result = "";
      if (userName != null)
      {
         result = "Hello, " + userName + "!";
      }
      ModelAndView view = new ModelAndView("hello_view");
      view.addObject("greeting", result);
      return view;
   }

   public String hjk(HttpServletRequest request, HttpServletResponse response) throws Exception
   {
      ModelAndView view2 = new ModelAndView("hello_view2");
      return view2.getViewName();
   }

   static class StaticNestedClass
   {
      static final String str = "blabla";
   }
}
