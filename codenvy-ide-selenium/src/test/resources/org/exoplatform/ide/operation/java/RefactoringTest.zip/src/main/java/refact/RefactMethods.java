package helloconection;

import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import helloworld.GreetingController;

public class RefactMethods extends GreetingController
{

   int ForCheckVal = val + 4545;

   String forCheckPbl = pbl.toLowerCase();

   String nstr = name.toUpperCase();
}