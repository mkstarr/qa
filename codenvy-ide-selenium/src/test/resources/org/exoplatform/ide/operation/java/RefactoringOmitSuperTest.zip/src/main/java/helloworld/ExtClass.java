package helloworld;

public class ExtClass extends Base
{

   protected double wideValue = 465465465.4488493;
   protected String[] arr;
}
