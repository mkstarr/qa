package helloworld;
import net.twonky.StringCheck;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GreetingController implements Controller
{

   @Override
   public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception
   {
      String userName = request.getParameter("user");
      String result = "";
      new StringCheck();
      boolean chk;
      chk=StringCheck.isUpper(result);
      
      if (userName != null && chk==false)
      {
         result = "Hello, " + userName + "!";
      }

      ModelAndView view = new ModelAndView("hello_view");
      view.addObject("greeting", result);
      return view;
   }

   public String hjk(HttpServletRequest request, HttpServletResponse response) throws Exception
   {
      ModelAndView view2 = new ModelAndView("hello_view2");
      return view2.getViewName();
   }
}
