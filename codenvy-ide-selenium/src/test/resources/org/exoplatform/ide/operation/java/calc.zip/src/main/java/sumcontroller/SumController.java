package sumcontroller;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


 
 
public class SumController extends AbstractController {
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ModelAndView mav = new ModelAndView("/calc.jsp");
        try {
            int x = Integer.parseInt(request.getParameter("x"));
            int y = Integer.parseInt(request.getParameter("y"));
            int sum = x + y;
            mav.addObject("sum", sum);
            mav.addObject("x", x);
            mav.addObject("y", y);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return mav;
    }
}