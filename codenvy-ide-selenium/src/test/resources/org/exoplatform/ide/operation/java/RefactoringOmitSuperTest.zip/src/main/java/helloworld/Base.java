package helloworld;

public class Base
{

   private String initString;

   private double value;

   public Base(String inStr, double inVal)
   {
      this.initString = inStr;
      
      this.value = inVal;
   }

}