package hello;
  
 /**
 * Hello world!
 *
 */

public class SayHello 
{
    public static String sayHello(String name)
    {
        return "Hello, " + name;
    }
}
