# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Hello::Application.config.secret_token = '790decce30df6a93f6edf65d44792e1b99fe9774ce1cc8fd3a6363acee0d064ea7e15f8171df59657646d2495dbc83658b0db1f6d3eae908b507f85458f2227f'
