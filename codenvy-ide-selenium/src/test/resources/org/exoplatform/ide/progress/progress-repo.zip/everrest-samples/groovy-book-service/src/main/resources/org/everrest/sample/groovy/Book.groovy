package org.everrest.sample.groovy

class Book
{
   String title
   String author
   int pages
   double price
   String id
}