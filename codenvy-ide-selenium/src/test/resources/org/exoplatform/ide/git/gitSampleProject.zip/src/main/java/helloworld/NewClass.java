package helloworld;

public class NewClass
{
   public double bigValuenewMTd()
   {
      final double pi = 3.14159265;
      return pi;
   }
}

