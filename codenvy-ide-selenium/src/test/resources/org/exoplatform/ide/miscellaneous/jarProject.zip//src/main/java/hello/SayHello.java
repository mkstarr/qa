package hello;
  
 /**
 * Hello world!
 *
 */

public class SayHello 
{
    public String sayHello(String name)
    {
        return "Hello, " + name;
    }
}
